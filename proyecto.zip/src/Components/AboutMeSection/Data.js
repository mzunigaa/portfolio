import image2 from '../../images/moni.jpeg'

export const homeObjOne = {
    id: 'aboutme',
    lightBg: true,
    lightText: false,
    lightTextDesc: false,
    topLine: '',
    headline: 'About me.',
    description: 'Software Engineering student with a Bachelo`s Degree in Civil Engineering and currently looking for a great opportunity in the area of ​​technologies.',
    description2: 'My skills include creativity, focus on goal achievement, and teamwork. I am passionate about creating and developing solutions through programming.',
    buttonLabel: 'Download resume',
    imgStart: true,
    img: image2,
    alt: 'Car',
    dark: false,
    primary: false,
    darkText: true
}
