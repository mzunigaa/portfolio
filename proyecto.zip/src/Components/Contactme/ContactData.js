import image1 from '../../images/contact.svg'

export const homeObjTwo = {
    id: 'contact',
    lightBg: false,
    lightText: true,
    lightTextDesc: true,
    topLine: '',
    headline: 'Contact me',
    description: '   mozunigaa@gmail.com',
    description2: '  (+506) 8995-9062',
    description3: '  @MonicaZunigaA',
    buttonLabel: '',
    imgStart: false,
    img: image1,
    alt: 'Car',
    dark: true,
    primary: true,
    darkText: false
}